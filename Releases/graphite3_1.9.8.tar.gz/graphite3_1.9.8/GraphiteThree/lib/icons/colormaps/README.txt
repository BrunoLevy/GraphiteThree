Provenance of the colormaps: https://bids.github.io/colormap/ 

