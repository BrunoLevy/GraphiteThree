Topological Optimization, by Jeremie Dumas.
