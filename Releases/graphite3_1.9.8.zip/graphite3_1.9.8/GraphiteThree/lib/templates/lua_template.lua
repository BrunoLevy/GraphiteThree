-- Lua (keep this comment, it is an indication for editor's 'run' command)

console_gui.show()
print('hello, world\n')

