### Installing a pre-compiled version of Graphite

- Download Graphite [here](http://gforge.inria.fr/frs/?group_id=1465), in the "Graphite /// for users" section.
- Unpack the zip file (where you want)
- To start Graphite, double-click on the "graphite.bat" file
- Alternatively, you may create on the desktop a shortcut to bin/win64/graphite.exe
