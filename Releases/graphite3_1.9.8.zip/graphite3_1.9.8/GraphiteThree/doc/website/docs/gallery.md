# Gallery

<br>
<center>

<div class="col-md-6"  markdown="1">

<iframe title="Test" width="426" height="240" allowfullscreen="allowfullscreen" src="https://www.youtube.com/embed/V7zHuVB_Oug"> 
</iframe> <br/>
Surface reconstruction and remeshing
<hr/>

<iframe title="Test" width="426" height="240" allowfullscreen="allowfullscreen" src="https://www.youtube.com/embed/W_jfpXPVY9g">
</iframe> <br/>
Voronoi mesher and subdivision surfaces 
<hr/>

<iframe title="Test" width="426" height="240" allowfullscreen="allowfullscreen" src="https://www.youtube.com/embed/guGyJwjeL4w">
</iframe> <br/>
Graphite polyhedral mesher, OpenVolumeMesh export
<hr/>

<iframe title="Test" width="426" height="240" allowfullscreen="allowfullscreen" src="https://www.youtube.com/embed/LmU4jHTzyyc">
</iframe> <br/>
Using and editing shaders from ShaderToys
<hr/>


</div> <div class="col-md-6"  markdown="1">

<iframe title="Test" width="426" height="240" allowfullscreen="allowfullscreen" src="https://www.youtube.com/embed/-47kRP6ByuA"> 
</iframe>
Volumic meshing (TetGen), attributes and visualizing cross-sections
<hr/>

<iframe title="Test" width="426" height="240" allowfullscreen="allowfullscreen" src="https://www.youtube.com/embed/3V5vW6skohQ">
</iframe> 
Manifold Harmonics
<hr/>

<iframe title="Test" width="426" height="240" allowfullscreen="allowfullscreen" src="https://www.youtube.com/embed/kc2DD_KzKqA">
</iframe> 
Hausdorff distance between two meshes 
<hr/>

<iframe title="Test" width="426" height="240" allowfullscreen="allowfullscreen" src="https://www.youtube.com/embed/9TeyR-JuXWM">
</iframe> 
Creating simple 3D graphics using Lua programs
<hr/>

</div>


</center>
