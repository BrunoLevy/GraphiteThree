# Online demos

Geogram programs can be embedded in the browser thanks to the Emscripten build (see [Building instructions](install_geogram.md)).

- [Optimal transport](https://members.loria.fr/Bruno.Levy/GEOGRAM/vorpaview.html)
- [Lloyd relaxation](https://members.loria.fr/Bruno.Levy/GEOGRAM/geogram_demo_Delaunay2d.html)
- [Sphere evasion](https://members.loria.fr/Bruno.Levy/GEOGRAM/geogram_demo_Evert.html)
