#include "f2c.h"

#ifdef KR_headers
extern double sin(), cos(), sinh(), cosh();

VOID c_cos(r, z) complex *r, *z;
#else
#undef abs
#include "math.h"
#ifdef complex /* [BL] MSVC defines a complex macro that collides with f2c's complex */
#undef complex
#endif

#ifdef __cplusplus
extern "C" {
#endif

void c_cos(complex *r, complex *z)
#endif
{
	double zi = z->i, zr = z->r;
	r->r =   cos(zr) * cosh(zi);
	r->i = - sin(zr) * sinh(zi);
	}
#ifdef __cplusplus
}
#endif
