*** Settings ***
Test Setup        Prepare Test
Test Teardown     Cleanup Test
Force Tags        Delaunay    smoke    daily
Library           OperatingSystem
Library           String
Library           lib/VorpatestLibrary.py

*** Variables ***
${DATADIR}        %{VORPATEST_ROOT_DIR}${/}data${/}Small

*** Test Cases ***
cube.obj
    [Tags]    daily_valgrind
    Run Test    cube.obj    dbg:delaunay_verbose=true

joint.off
    [Tags]    daily_valgrind
    Run Test    joint.off    dbg:delaunay_verbose=true

fandisk.ply
    [Tags]    weekly_valgrind
    Run Test

cube.obj (hull)
    [Tags]    daily_valgrind
    Run Test    cube.obj    convex_hull=true    dbg:delaunay_verbose=true

joint.off (hull)
    [Tags]    daily_valgrind
    Run Test    joint.off    convex_hull=true    dbg:delaunay_verbose=true

fandisk.ply (hull)
    [Tags]    weekly_valgrind
    Run Test    fandisk.ply    convex_hull=true

cube.obj (2d)
    [Tags]    daily_valgrind
    Run Test    cube.obj    dimension=2

joint.off (2d)
    [Tags]    daily_valgrind
    Run Test    joint.off    dimension=2

fandisk.ply (2d)
    [Tags]    weekly_valgrind
    Run Test    fandisk.ply    dimension=2

joint.off (2d triangle)
    [Tags]    daily_valgrind
    Run Test    joint.off    dimension=2   algo:delaunay=triangle

joint.off (periodic)
    [Tags]    daily_valgrind
    Run Test Periodic   joint.off

joint.off (periodic but not periodic)
    [Tags]    daily_valgrind
    Run Test Periodic But Not Periodic   joint.off

PDEL BRIO vertex coverage
    run command    test_delaunay_3d


*** Keywords ***
Run Test
    [Arguments]    ${input_name}=${TEST NAME}    @{options}
    [Documentation]    Runs compute_delaunay on a single input file.
    ...    The name of the input file is taken from the test name.
    run command    compute_delaunay  ${DATADIR}${/}${input_name}  dbg:delaunay_benchmark=true   @{options}

Run Test Periodic
    [Arguments]    ${input_name}=${TEST NAME}    @{options}
    [Documentation]    Runs compute_delaunay on a single input file.
    ...    The name of the input file is taken from the test name.
    run command    compute_delaunay_periodic  ${DATADIR}${/}${input_name}  periodic=true  normalize=true  detailed_verbose=true   @{options}  out

Run Test Periodic But Not Periodic
    [Arguments]    ${input_name}=${TEST NAME}    @{options}
    [Documentation]    Runs compute_delaunay on a single input file.
    ...    The name of the input file is taken from the test name.
    run command    compute_delaunay_periodic  ${DATADIR}${/}${input_name}  periodic=false  normalize=true  detailed_verbose=true   @{options}  out
